<?php

echo "Hello, PHP!";
