---
name: Bug report
about: Report an incorrect lesson, broken example, or documentation issue
title: "[BUG] "
labels: bug
---

## What happened?

## Which lesson or file?

## Steps to reproduce

## Expected result

## Actual result

## PHP version
