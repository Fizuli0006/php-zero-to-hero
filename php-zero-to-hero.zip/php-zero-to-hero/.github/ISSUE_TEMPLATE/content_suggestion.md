---
name: Content suggestion
about: Suggest a lesson, exercise, translation, or improvement
title: "[CONTENT] "
labels: documentation
---

## What should be added or improved?

## Why is it useful for learners?

## Suggested example or reference
